# AddicoreRFID
Arduino Library for the RC522 MIFARE RFID Module available from Addicore at https://www.addicore.com/RFID-AddiKit-p/126.htm
